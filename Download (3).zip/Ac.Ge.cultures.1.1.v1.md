# Active Cultures of Mania — Working Reference List
*Compiled for second draft. Organized by section with notes on application.*

---

## Section V.1 — The Central Reframe: Mania as Misaimed Control

**Core source — BAS as goal-directed energy:**
- Johnson, S. L., et al. (2012). The behavioral activation system and mania. *Annual Review of Clinical Psychology*, 8, 243–267.
  - *Use for:* Establishing that mania is fundamentally organized around heightened goal-directed behavior and reward pursuit — not random excess. The energy is structured. The targeting is off.

**Supporting — BAS dysregulation model:**
- Alloy, L. B., et al. (2009). Role of the behavioral activation system in vulnerability to bipolar spectrum disorders. *Journal of Abnormal Psychology*, 118(2), 407–422.
  - *Use for:* BAS sensitivity predicting onset, course, and severity of mania — supports the argument that mania is a calibration problem, not a volume problem.

**Supporting — indiscriminate aim:**
- Fulford, D., et al. (2011). fMRI evidence of a relationship between hypomania and both increased goal-sensitivity and positive outcome-expectancy bias. *Acta Psychiatrica Scandinavica*, 124(3), 209–218. [PMID: 21703286]
  - *Use for:* The machinery works — the targeting fails. "Insatiable and indiscriminate reward-seeking" is almost exactly your framing. Cite as convergent, then note your paper goes further by accounting for plural systems.

**Supporting — misaimed drive language:**
- Psychology Town. (2026, March 6). When conation fails: Pathological impacts on mental health. https://psychology.town/fundamentals-of-mental-health/conation-failure-impacts-mental-health/
  - *Use for:* Explicit framing of mania as "pathologically amplified" drive where the problem is a failure of adaptive self-regulation — not the energy itself but its direction. Convergent lay-adjacent source; note your paper formalizes this in a plural context.

---

## Section V.4 — Managed Episodes Have Hidden Costs

**Core source — syndromal vs. functional recovery gap:**
- Tohen, M., et al. (2000). Two-year syndromal and functional recovery in 219 cases of first-episode major affective disorder with psychotic features. *American Journal of Psychiatry*, 157(2), 220–228.
  - *Use for:* Functional disability persists in up to 60% of patients after hospitalization for mania even when syndromal recovery is attained. The mainstream literature already sees the gap between "episode over" and "person okay." Your paper explains it from the inside.

**Supporting — functional recovery lag:**
- van der Voort, T. Y. G., et al. (2015). Functional versus syndromal recovery in patients with major depressive disorder and bipolar disorder. *Journal of Clinical Psychiatry*, 76(6). [PMID: 26132690]
  - *Use for:* Functional recovery may take up to a year after syndromal remission. Establishes the timeline your paper is working inside.

**Supporting — post-manic depressive switch, research gap:**
- Salmeron, S., et al. (2025). From fire to ashes: A six-month follow-up prospective study of manic patients after acute inward hospitalisation. *European Psychiatry*. [PMC12436806]
  - *Use for:* Post-episodic monitoring has "little evidence supporting its risks and needs" — your paper is writing directly into that documented gap.

**Supporting — hypersomnia prevalence post-mania:**
- Harvey, A. G., et al. (2006). The role of sleep in bipolar disorder. *Nature and Science of Sleep*, 8, 399. [PMC4935164]
  - *Use for:* Hypersomnia rates of 38–78% in bipolar patients during post-manic phases. Colbran's recovery state is documented, not incidental.

---

## Section V.2 — The Person Is the Entry Point

**Core source — neuroception of safety as prerequisite:**
- Porges, S. W. (2004). Neuroception: A subconscious system for detecting threats and safety. *Zero to Three*, 24(5), 19–24.
  - *Use for:* A neuroception of safety is neurologically required before social engagement behaviors can occur at all. Colbran couldn't be reached as a strategic asset because his nervous system was in threat-assessment mode. The sequence wasn't therapeutic preference — it was physiological necessity.

**Supporting — feeling safe vs. being safe:**
- Porges, S. W. (2022). Polyvagal theory: A science of safety. *Frontiers in Integrative Neuroscience*, 16. https://doi.org/10.3389/fnint.2022.871227
  - *Use for:* Safety is defined by *feeling* safe, not simply the removal of threat — requires three specific conditions including activation of the social engagement system. Maps directly onto what the system did with Colbran before asking anything of him functionally.

**Core source — therapeutic alliance in dissociative disorders:**
- Cronin, E., Brand, B. L., & Mattanah, J. F. (2014). The impact of the therapeutic alliance on treatment outcome in patients with dissociative disorders. *European Journal of Psychotraumatology*, 5, 22676. [PMID: 24616755]
  - *Use for:* Alliance predicted better outcomes in DD patients even after controlling for symptom management — and effect sizes were stronger than in most other patient populations. Relational safety is *more* important in dissociative presentations, not less.

**Supporting — IFS safety-before-function:**
- Schwartz, R. C. (1995). *Internal Family Systems Therapy*. Guilford Press.
  - *Use for:* Protective parts must feel safe before allowing access to deeper function — the person-before-function principle is recognized across multiple independent frameworks. Cite as convergent.

---

## Section IV / V.5 — Crisis Builds / Predictive Processing

**Core source — trauma as prediction error accumulation:**
- Krystal, J. H., & Anticevic, A. (2020). Predictive processing in mental illness: Hierarchical circuitry for perception and trauma. *Journal of Abnormal Psychology*, 129(7). [PMID: 32757606]
  - *Use for:* Trauma-related disorders identified as disorders of excessive accumulated prediction errors. When existing models fail catastrophically, the brain builds new ones. Adam's formation is this process made visible and named.

**Supporting — dissociation as computationally coherent:**
- [Author TBC]. (2025). Forecasting pain: Predictive processing model for trauma-driven affective suppression. Academia.edu preprint.
  - *Use for:* Dissociative behaviors reframed as computationally coherent strategies to reduce surprise — not avoidance, but the brain doing what it does when models break down. Convergent with your argument; note your paper adds the plural-specific dimension. *Check peer review status before citing.*

**Supporting — Friston free energy principle:**
- Friston, K. (2010). The free-energy principle: A unified brain theory? *Nature Reviews Neuroscience*, 11(2), 127–138.
  - *Use for:* Already cited in Brie-f Equations. Reuse here — adaptive systems generate new models when existing ones fail. In plural systems, those models have names.

**Core source — posttraumatic growth framework:**
- Tedeschi, R. G., & Calhoun, L. G. (2004). Posttraumatic growth: Conceptual foundations and empirical evidence. *Psychological Inquiry*, 15(1), 1–18.
  - *Use for:* PTG establishes that adversity produces positive changes — your paper takes this further by arguing that in plural systems the growth doesn't just change the person, it *creates* one. Adam isn't a changed Cain. Adam is new. Cite PTG as the closest existing framework, then mark the gap clearly.

---

## Section IV — Adam: Interoception, Severance, and the Anger Function

**Core source — interoception disruption after trauma:**
- Leech, R., et al. (2024). The relationship between interoception and experiences of stress, trauma, and mental illness: A scoping review. *Psychotherapy and Counselling Journal of Australia*.
  - *Use for:* Consistent association between trauma and reduced body awareness across clinical presentations — typically manifesting as reduced awareness and difficulty interpreting internal sensations. Adam's severed interoception is documented, not unusual.

**Supporting — brainstem-level processing disruption:**
- Ciszewski, S., et al. (2023). Interoception in fear learning and posttraumatic stress disorder. *Focus*, 21(3). [PMC10316209]
  - *Use for:* Traumatic events disrupt brainstem-level processing of physical sensations, causing downstream breakdowns in body signal integration including dissociative numbing. The channel was damaged at the processing level, not just awareness. This is the mechanism under the accidents.

**Core source — van der Kolk on interoception loss:**
- van der Kolk, B. (2014). *The Body Keeps the Score: Brain, Mind, and Body in the Healing of Trauma*. Viking Press.
  - *Use for:* Traumatized individuals often lose interoception, leading to alexithymia — inability to put feelings into words. Adam can't put hunger into words because the system literally couldn't feel it.

**Bonus — live debate worth engaging:**
- Kotler, S., Mannino, M., Fox, G., & Friston, K. (2026). The body does not keep the score: Trauma, predictive coding, and the restoration of metastability. *Frontiers in Systems Neuroscience*. https://doi.org/10.3389/fnsys.2026.1812957
  - *Use for:* 2026 paper challenging van der Kolk — argues trauma is a disorder of prediction, not storage. Your paper bridges both: Adam holds the archive *and* functions as an alarm when the predictive model breaks down. You don't have to pick a side. Your data shows both things happening simultaneously, which is itself a finding worth naming.

---

## Carry Forward from Prior Papers

These are already cited in Rind and Core, Whey Beyond Coping, or Brie-f Equations and should remain in Active Cultures for continuity:

- Lanius, R. A., et al. (2012). Emotion modulation in PTSD: Clinical and neurobiological evidence for a dissociative subtype. *American Journal of Psychiatry*, 167(6), 640–647.
- van der Hart, O., Nijenhuis, E. R. S., & Steele, K. (2006). *The Haunted Self: Structural Dissociation and the Treatment of Chronic Traumatization*. Norton.
- Brand, B. L., Armstrong, J. G., & Loewenstein, R. J. (2006). Psychological assessment of patients with dissociative identity disorder. *Psychiatric Clinics of North America*, 29(1), 145–168.
- Clark, A. (2013). Whatever next? Predictive brains, situated agents, and the future of cognitive science. *Behavioral and Brain Sciences*, 36(3), 181–204.
- Friston, K. (2010). The free-energy principle: A unified brain theory? *Nature Reviews Neuroscience*, 11(2), 127–138.

---

*Notes for second draft:*
- *The managed episode costs section may be the most original contribution — the literature sees the gap but doesn't explain it. Lead with the data, cite the gap, then provide the mechanism.*
- *The Kotler/Friston 2026 paper is brand new and directly relevant to Adam's section — worth engaging explicitly rather than just citing.*
- *All BAS sources can be grouped in a single paragraph; they are cumulative rather than each making a distinct point.*
- *The Forecasting Pain preprint needs peer review status checked before final submission.*
